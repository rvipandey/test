STOP_WORDS = set(
    """
a à â a-a a-e a-i a-o aiva aloa an ancheu ancon apreuvo ascì atra atre atri atro avanti avei

bella belle belli bello ben

ch' che chì chi ciù co-a co-e co-i co-o comm' comme con cösa coscì cöse

d' da da-a da-e da-i da-o dapeu de delongo derê di do doe doî donde dòppo

é e ê ea ean emmo en ëse

fin fiña

gh' ghe guæei

i î in insemme int' inta inte inti into

l' lê lì lô

m' ma manco me megio meno mezo mi

na n' ne ni ninte nisciun nisciuña no

o ò ô oua

parte pe pe-a pe-i pe-e pe-o perché pittin pö primma pròpio

quæ quand' quande quarche quella quelle quelli quello

s' sce scê sci sciâ sciô sciù se segge seu sò solo son sott' sta stæta stæte stæti stæto ste sti sto

tanta tante tanti tanto te ti torna tra tròppo tutta tutte tutti tutto

un uña unn' unna

za zu
""".split()
)
